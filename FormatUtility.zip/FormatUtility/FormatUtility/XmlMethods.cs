﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace FormatUtility
{
    public class XmlMethods
    {
        /// <summary>
        /// Create an XML file from a CSV source file using Excel template to get XML structure
        /// </summary>
        /// <param name="csvSourceFile">CSV source file</param>
        /// <param name="excelTemplatePath">Excel template where structure is define</param>
        /// <param name="xmlResultPath">XML final result file path</param>
        /// <returns>OK or error message</returns>
        public static string CreateXmlResultFile(string sourceFile, Dictionary<string, string> dictFieldType, string xmlFile)
        {
            string returnValue = "OK";

            try
            {

                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);

                XmlNode xmlRootDocNode;
                XmlNode HeaderNode;
                XmlNode ItemsNode=null;
                XmlNode HeaderItemNode;
                XmlNode ItemNode;
                XmlNode ItemValueNode;

                int indexItemSection = 1;
                bool isItemSectionFound = true;

                IEnumerable<KeyValuePair<string, string>> dictTableValues = null;

                //Get CSV object from CSV source file
                CsvMethods objCsvMethods = new CsvMethods();
                objCsvMethods.SetFile(sourceFile);

                //Define Structure
                xmlRootDocNode = doc.CreateElement("File");
                doc.AppendChild(xmlRootDocNode);

                HeaderNode = doc.CreateElement("Header");
                xmlRootDocNode.AppendChild(HeaderNode);

                var dictFormValues = from entry in dictFieldType
                                     where entry.Value.Contains("Form")
                                     select entry;

                foreach (KeyValuePair<string, string> entryForm in dictFormValues)
                {
                    HeaderItemNode = doc.CreateElement(entryForm.Key);
                    HeaderItemNode.AppendChild(doc.CreateTextNode(objCsvMethods.Get_Cell_Content(entryForm.Key, 1)));
                    HeaderNode.AppendChild(HeaderItemNode);
                }

                //Add table values
                while (isItemSectionFound)
                {
                    if (indexItemSection == 1)
                    {
                        dictTableValues = from entry in dictFieldType
                                          where entry.Value.ToLower() == String.Format("table{0}", indexItemSection) || entry.Value.ToLower() == "table"
                                          select entry;
                    }
                    else
                    {
                        dictTableValues = from entry in dictFieldType
                                          where entry.Value.ToLower() == String.Format("table{0}", indexItemSection)
                                          select entry;
                    }

                    if (dictTableValues.Count() != 0)
                    {
                        for (int indexLine = 1; indexLine < objCsvMethods.dict.Count; indexLine++)
                        {
                            if (indexLine == 1)
                            {
                                ItemsNode = doc.CreateElement(String.Format("Table{0}", indexItemSection));
                                xmlRootDocNode.AppendChild(ItemsNode);
                            }

                            ItemNode = doc.CreateElement(string.Format("Table{0}_Item{1}",indexItemSection,indexLine));
                            ItemsNode.AppendChild(ItemNode);

                            foreach (KeyValuePair<string, string> entryItem in dictTableValues)
                            {

                                ItemValueNode = doc.CreateElement(entryItem.Key);
                                ItemValueNode.AppendChild(doc.CreateTextNode(objCsvMethods.Get_Cell_Content(entryItem.Key, indexLine)));
                                ItemNode.AppendChild(ItemValueNode);

                            }
                        }
                    }
                    else
                        isItemSectionFound = false;

                    indexItemSection++;
                }

                doc.Save(xmlFile);
            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            return returnValue;
        }

    }
}
