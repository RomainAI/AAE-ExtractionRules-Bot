﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FormatUtility
{
    public class ExtractionRulesMethods
    {

        /// <summary>
        /// Apply extraction rules based on CSV file rules, convert CSV file to XML and/or JSON
        /// </summary>
        /// <param name="sourceFile">CSV source file</param>
        /// <param name="extractionRulesFile">Extraction rules file</param>
        /// <param name="convertFile">Convert CSV to XML and/or JSON</param>
        /// <returns>OK or execption message</returns>
        public static string ApplyExtractionRules(string sourceFile, string extractionRulesFile, string convertFile)
        {
            string returnResult = "OK";

            //Source file variable
            CsvMethods objCsvSourceFile = null;
            IDictionary<int, List<string>> objDisctionarySourceFile = null;

            //Extraction rules file variable
            CsvMethods objCsvExtractionFile = null;
            IDictionary<int, List<string>> objDisctionaryExtractionFile = null;

            Dictionary<string, string> dictFieldType = new Dictionary<string, string>();
            Dictionary<string, string> dictColumnToRename = new Dictionary<string, string>();
            Dictionary<int, List<string>> linesToRemove = new Dictionary<int, List<string>>();
            
            string columnName = "";
            string columnType = "";
            string regexExtraction = "";
            string replaceValues = "";
            string formatType = "";
            string formatValue = "";
            string trimValue = "";
            string removeSpaces = "";
            string newColumnName = "";
            string removeLineIfRegex = "";
            string keepLineIfRegex = "";
            string bestMatchListFile = "";
            string bestMatchConfidence = "";

            string sourceValue = "";

            int indexLineExtractionFile = 0;
            int indexLineSoureFile = 0;
            bool isLineDeleted = false;
            int isRegexFound = 0;
            double confidenceLevel = 0;

            try
            {
                if (Path.GetExtension(sourceFile).ToLower() != ".csv")
                    return "Not a CSV file";
                //Initiate CSV object for both Extraction rules and source file
                objCsvSourceFile = new CsvMethods();
                objCsvSourceFile.SetFile(sourceFile);
                objDisctionarySourceFile = objCsvSourceFile.dict;

                objCsvExtractionFile = new CsvMethods();
                objCsvExtractionFile.SetFile(extractionRulesFile);
                objDisctionaryExtractionFile = objCsvExtractionFile.dict;

                //For each line in extraction rules file
                foreach (KeyValuePair<int, List<string>> entryExtractionFile in objDisctionaryExtractionFile)
                {
                    if (indexLineExtractionFile != 0)
                    {
                        columnName = objCsvExtractionFile.Get_Cell_Content("Column_Name", indexLineExtractionFile).Trim();
                        columnType = objCsvExtractionFile.Get_Cell_Content("Column_Type", indexLineExtractionFile).Trim();
                        regexExtraction = objCsvExtractionFile.Get_Cell_Content("Regex_Extraction", indexLineExtractionFile).Trim();
                        replaceValues = objCsvExtractionFile.Get_Cell_Content("Replace_Values", indexLineExtractionFile).Trim();
                        formatType = objCsvExtractionFile.Get_Cell_Content("Format_Type", indexLineExtractionFile).Trim();
                        formatValue = objCsvExtractionFile.Get_Cell_Content("Format_Value", indexLineExtractionFile).Trim();
                        trimValue = objCsvExtractionFile.Get_Cell_Content("Trim_Value", indexLineExtractionFile).Trim();
                        removeSpaces = objCsvExtractionFile.Get_Cell_Content("Remove_Spaces", indexLineExtractionFile).Trim();
                        newColumnName = objCsvExtractionFile.Get_Cell_Content("New_Column_Name", indexLineExtractionFile).Trim();
                        removeLineIfRegex = objCsvExtractionFile.Get_Cell_Content("Remove_Line_If_Regex", indexLineExtractionFile).Trim();
                        keepLineIfRegex = objCsvExtractionFile.Get_Cell_Content("Keep_Line_If_Regex", indexLineExtractionFile).Trim();
                        bestMatchListFile = objCsvExtractionFile.Get_Cell_Content("Best_Match_List_File", indexLineExtractionFile).Trim();
                        bestMatchConfidence = objCsvExtractionFile.Get_Cell_Content("Best_Match_Confidence", indexLineExtractionFile).Trim();
                    }

                    indexLineExtractionFile++;

                    if (indexLineExtractionFile > 1)
                    {
                        indexLineSoureFile = 0;
                        foreach (KeyValuePair<int, List<string>> entrySourceFile in objDisctionarySourceFile)
                        {
                            if (indexLineSoureFile != 0)
                            {
                                isLineDeleted = false;

                                sourceValue = objCsvSourceFile.Get_Cell_Content(columnName, indexLineSoureFile);

                                //Build column list
                                if (indexLineSoureFile == 1)
                                {
                                    if (newColumnName != string.Empty)
                                    {
                                        dictFieldType.Add(newColumnName, columnType);
                                        dictColumnToRename.Add(columnName, newColumnName);
                                    }
                                    else
                                        dictFieldType.Add(columnName, columnType);
                                }

                                //Remove this entry is "removeLineIfRegex" has been found
                                if (removeLineIfRegex != string.Empty)
                                {
                                    isRegexFound = ExtractingValue.GetIsRegexFound(sourceValue, removeLineIfRegex);
                                    if (isRegexFound == 1)
                                    {
                                        linesToRemove.Add(entrySourceFile.Key, entrySourceFile.Value);
                                        isLineDeleted = true;
                                    }

                                }

                                //Remove this entry is "keepLineIfRegex" hasn't been found
                                if (!isLineDeleted && keepLineIfRegex != string.Empty)
                                {
                                    isRegexFound = ExtractingValue.GetIsRegexFound(sourceValue, keepLineIfRegex);
                                    if (isRegexFound == 0)
                                    {
                                        linesToRemove.Add(entrySourceFile.Key, entrySourceFile.Value);
                                        isLineDeleted = true;
                                    }
                                }

                                //If line hasn't been deleted
                                if (!isLineDeleted)
                                {
                                    if (sourceValue == null)
                                        sourceValue = string.Empty;

                                    //1 - Remove spaces
                                    if (removeSpaces == "1" || removeSpaces.ToLower() == "y")
                                        sourceValue = sourceValue.Replace(" ", string.Empty);

                                    //2 - Extract matching regex from new value
                                    if (regexExtraction != string.Empty)
                                        sourceValue = ExtractingValue.ExtractValueMatchRegex(sourceValue, regexExtraction, sourceValue);

                                    //3 - Replace values from source value
                                    if (replaceValues != string.Empty)
                                        sourceValue = StringFormatMethods.ReplaceValues(sourceValue, replaceValues, sourceValue);

                                    //4 - Trim value
                                    if (trimValue == "1" || trimValue.ToLower() == "y")
                                        sourceValue = sourceValue.Trim();

                                    //5 - Format value
                                    if (formatType != string.Empty)
                                    {
                                        if (formatType.ToLower() == "numeric" || formatType.ToLower() == "number")
                                            sourceValue = NumericFormatMethods.GetFormattedNumber(sourceValue, formatValue, sourceValue);
                                        else if (formatType.ToLower() == "date")
                                            sourceValue = DateFormatMethods.GetFormattedDate(sourceValue, formatValue, sourceValue);
                                    }

                                    //6 - Best match file
                                    if (bestMatchListFile != string.Empty)
                                    {
                                        try
                                        {
                                            confidenceLevel = Convert.ToDouble(bestMatchConfidence);
                                            sourceValue = ExternalListMethods.GetBestMatchResult(bestMatchListFile, sourceValue, confidenceLevel);
                                        }
                                        catch
                                        { }
                                    }

                                    //Add "" if needed
                                    if (sourceValue.Contains(",") || sourceValue.Contains("\""))
                                        sourceValue = string.Format("\"{0}\"", sourceValue.Replace("\"", "").Trim());

                                    //Save cell value
                                    objCsvSourceFile.Save_Cell_Value_No_Save(columnName, indexLineSoureFile, sourceValue);

                                }

                            }

                            indexLineSoureFile++;
                        }
                    }
                }

                //Rename column
                foreach (KeyValuePair<string, string> renameEntry in dictColumnToRename)
                    objCsvSourceFile.Rename_Column(renameEntry.Key, renameEntry.Value);

                //Remove deleted lines
                foreach (KeyValuePair<int, List<string>> entryToRemove in linesToRemove)
                    objDisctionarySourceFile.Remove(entryToRemove);

                linesToRemove.Clear();

                //Save CSV file
                objCsvSourceFile.Save_File_As_CSV(sourceFile);

                //Convert to XML
                if (convertFile.ToLower().Contains("xml"))
                    XmlMethods.CreateXmlResultFile(sourceFile, dictFieldType, sourceFile.Replace(".csv", ".xml"));

                if (convertFile.ToLower().Contains("json"))
                    JsonMethods.CreateJsonResultFile(sourceFile, dictFieldType, sourceFile.Replace(".csv", ".json"));

            }
            catch (Exception ex)
            {
                returnResult = ex.Message;
            }
            return returnResult;
        }

        /// <summary>
        /// Create a CSV file with all file content from CSV files in source folder (source files need to have same columns order)
        /// </summary>
        /// <param name="sourceFolder">Folder with all source CSV files</param>
        /// <param name="reportFile">Final report file path</param>
        /// <returns>OK or exception message</returns>
        public static string CreateFlatReport(string sourceFolder, string reportFile)
        {
            string returnValue = "OK";
            StreamReader streamReader = null;
            string line = string.Empty;
            bool isFirstFile = true;
            string allText = string.Empty;
            string fileName = string.Empty;

            try
            {
                if (File.Exists(reportFile))
                    File.Delete(reportFile);

                foreach (string file in Directory.GetFiles(sourceFolder))
                {
                    fileName = Path.GetFileName(file);
                    if (fileName.Contains("]_"))
                        fileName = fileName.Split(new[] { "]_" }, StringSplitOptions.None)[1];
                    streamReader = new StreamReader(file);
                    if (!isFirstFile)
                        streamReader.ReadLine();

                    while ((line = streamReader.ReadLine()) != null)
                    {
                        if (isFirstFile)
                        {
                            allText += string.Format("{0},{1}\r", "File_Name", line);
                            isFirstFile = false;
                        }
                        else
                            allText += string.Format("{0},{1}\r", fileName, line);
                    }
                    
                }
                File.AppendAllText(reportFile, allText);
            }
            catch (Exception ex)
            { returnValue = ex.Message; }

            return returnValue;
        }

    }
}
