﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Dynamic;
using System.IO;

namespace FormatUtility
{
    public class JsonMethods
    {

        /// <summary>
        /// Create a JSON file fron a CSV file (JSON structure difined in "dictFieldType")
        /// </summary>
        /// <param name="sourceFile">CSV source file</param>
        /// <param name="dictFieldType">List of field and type</param>
        /// <param name="jsonFile">Result JSON file</param>
        /// <returns>OK or exception message</returns>
        public static string CreateJsonResultFile(string sourceFile, Dictionary<string, string> dictFieldType, string jsonFile)
        {

            string returnValue = "OK";
            string propertyName = string.Empty;
            string propertyValue = string.Empty;
            string jsonData = string.Empty;

            int indexItemSection = 1;
            bool isItemSectionFound = true;

            IEnumerable<KeyValuePair<string,string>> dictTableValues = null;

            dynamic expandoJson = new ExpandoObject();
            dynamic expandoHeader = new ExpandoObject();
            dynamic expandoTable = new ExpandoObject();
            dynamic expandoItem = new ExpandoObject();

            var objJson = expandoJson as IDictionary<string, object>;
            var objHeader = expandoHeader as IDictionary<string, object>;            

            try
            {
                //Get CSV object from CSV source file
                CsvMethods objCsvMethods = new CsvMethods();
                objCsvMethods.SetFile(sourceFile);

                //Add header values
                var dictFormValues = from entry in dictFieldType
                                     where entry.Value.Contains("Form")
                                     select entry;

                foreach (KeyValuePair<string, string> entryForm in dictFormValues)
                {
                    propertyValue = objCsvMethods.Get_Cell_Content(entryForm.Key, 1).Replace("\"","");

                    if (objHeader.ContainsKey(entryForm.Key))
                        objHeader[entryForm.Key] = propertyValue;
                    else
                        objHeader.Add(entryForm.Key, propertyValue);

                }

                objJson.Add("Header", objHeader);

                //Add table values
                while (isItemSectionFound)
                {
                    if (indexItemSection == 1)
                    {
                        dictTableValues = from entry in dictFieldType
                                          where entry.Value.ToLower() == String.Format("table{0}", indexItemSection) || entry.Value.ToLower() == "table"
                                          select entry;
                    }
                    else
                    {
                        dictTableValues = from entry in dictFieldType
                                          where entry.Value.ToLower() == String.Format("table{0}", indexItemSection)
                                          select entry;
                    }

                    if (dictTableValues.Count() != 0)
                    {
                        var objTable = new ExpandoObject() as IDictionary<string, object>;

                        for (int indexLine = 1; indexLine < objCsvMethods.dict.Count; indexLine++)
                        {
                            var objItem = new ExpandoObject() as IDictionary<string, object>;

                            foreach (KeyValuePair<string, string> entryTable in dictTableValues)
                            {
                                propertyValue = objCsvMethods.Get_Cell_Content(entryTable.Key, indexLine).Replace("\"", "");

                                if (objItem.ContainsKey(entryTable.Key))
                                    objItem[entryTable.Key] = propertyValue;
                                else
                                    objItem.Add(entryTable.Key, propertyValue);
                            }
                            objTable.Add(string.Format("Table{0}_Item{1}",indexItemSection, indexLine), objItem);
                        }
                        objJson.Add(string.Format("Table{0}", indexItemSection), objTable);
                    }
                    else
                        isItemSectionFound = false;

                    indexItemSection++;
                }

                //Get JSON result string
                jsonData = JsonConvert.SerializeObject(objJson);

                if (File.Exists(jsonFile))
                    File.Delete(jsonFile);

                File.AppendAllText(jsonFile, jsonData);

            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            return returnValue;
        }

    }
}
