﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace FormatUtility
{
    public class CsvMethods
    {
        private String FilePath = "";
        private StreamReader reader;
        public IDictionary<int, List<String>> dict = new Dictionary<int, List<String>>();

        public CsvMethods() { }

        // Set the CSV file up to be processed and available as a C# Dictionary
        public void SetFile(String PathToCsvFile)
        {
            this.dict = new Dictionary<int, List<String>>();
            this.FilePath = PathToCsvFile;
            reader = new StreamReader(this.FilePath);
            int index = 0;
            while (!reader.EndOfStream)
            {
                // Turn each line of the file into an Array of Strings

                var line = reader.ReadLine();
                List<string> ValuesArray = new List<string>();

                // Some elements of CSVs are complex and have commas within them. Consider the following: 
                //      123,,"my test, here",345,hello  
                // This CSV line has 5 elements including an empty one and one that has a comma in its value
                // To accomodate for complex use cases, we use regular expressions:
                // (?:(?<=^)|(?<=,))(?:(?!$)\s)*"?((?<=").*?(?=")|((?!,).)*)"?(?:(?!$)\s)*(?=$|,)

                String RegExPattern = "(?:(?<=^)|(?<=,))(?:(?!$)\\s)*\"?((?<=\").*?(?=\")|((?!,).)*)\"?(?:(?!$)\\s)*(?=$|,)";
                Regex csvSplit = new Regex(RegExPattern, RegexOptions.Compiled);
                string curr = null;
                // each match is exactly one element of a CSV line
                foreach (Match match in csvSplit.Matches(line))
                {
                    curr = match.Value;

                    if (0 == curr.Length) // if the element is empty, we add an empty string to the array.
                    {
                        ValuesArray.Add(" ");
                    }
                    else
                    {
                        String currFiltered = curr.TrimEnd(',').Trim(' ');
                        ValuesArray.Add(currFiltered);
                    }
                }
                // Finally we add the Array into the dictionary modelling the csv file. the Key to each entry is the line number
                dict.Add(index, ValuesArray);
                index++;
            }
            reader.Close();
        }

        public int Get_Column_Index(String ColumnName)
        {
            String ProcessedColumnName = ColumnName.Trim('"');
            List<String> myListOfColumns = dict[0];
            int ColumnNumber = myListOfColumns.IndexOf(ProcessedColumnName);
            return ColumnNumber;
        }

        public String Get_Cell_Content(String ColumnName, int LineNumber)
        {
            List<String> myListOfColumns = dict[0];
            int ColumnNumber = myListOfColumns.IndexOf(ColumnName);
            if (ColumnNumber > -1)
            {
                List<String> myListOfValues = dict[LineNumber];
                return myListOfValues[ColumnNumber];
            }
            return null;
        }

        public void Save_Cell_Value_No_Save(String ColumnName, int LineNumber, String NewValue)
        {
            int ColumnIndex = Get_Column_Index(ColumnName);
            if (ColumnIndex > -1)
                this.dict[LineNumber][ColumnIndex] = NewValue;
        }

        public void Save_File_As_CSV(String InputFile)
        {
            var csv = new StringBuilder();

            foreach (KeyValuePair<int, List<String>> entry in this.dict)
            {
                var newLine = String.Join(",", entry.Value.ToArray());
                csv.AppendLine(newLine);
            }

            File.WriteAllText(InputFile, csv.ToString());
        }

        public Boolean Rename_Column(String CurrentColumnName, String NewColumnName)
        {
            
            int idx = Get_Column_Index(CurrentColumnName);
            if (idx > -1)
            {
                this.dict[0][idx] = NewColumnName;
                return true;
            }

            return false;
        }

    }
}
