﻿using FormatUtility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleTest
{
    class Class1
    {
        static void Main(string[] args)
        {
            

            string sourceFolder = @"C:\Users\Romain.Alexandre\Documents\Automation Anywhere Files\Automation Anywhere\My Docs\_Template - Post Process\IQ Bot Success";
            string sourceFile = @"C:\Users\Romain.Alexandre\Documents\Automation Anywhere Files\Automation Anywhere\My Docs\_Template - Post Process\Results\004995065-000000013.tif.csv";
            string extractionRulesFile = @"C:\Users\Romain.Alexandre\Documents\Automation Anywhere Files\Automation Anywhere\My Docs\_Template - Post Process\Extraction_Rules.csv";
            string reportFile = @"C:\Users\Romain.Alexandre\Documents\Automation Anywhere Files\Automation Anywhere\My Docs\_Template - Post Process\Report\Report.csv";

            //FormatUtility.ExtractionRulesMethods.CreateFlatReport(sourceFolder, reportFile);

            foreach (string file in Directory.GetFiles(sourceFolder))
            {
                sourceFile = file;
                FormatUtility.ExtractionRulesMethods.ApplyExtractionRules(sourceFile, extractionRulesFile, "xml,json");
            }


        }
        
    }
}
